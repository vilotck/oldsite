---
layout: post
---

This post is strange