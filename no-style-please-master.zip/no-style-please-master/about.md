---
layout: page
title: About
---

This is an example page!

It's very similar to a `post` layout, with the only difference that the publish date is not shown!